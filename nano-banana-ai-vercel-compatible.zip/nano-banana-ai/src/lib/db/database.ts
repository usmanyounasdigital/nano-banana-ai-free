import sqlite3 from 'sqlite3'
import { open, Database } from 'sqlite'
import path from 'path'

let db: Database | null = null

export async function getDatabase(): Promise<Database> {
  if (db) {
    return db
  }

  const dbPath = path.join(process.cwd(), 'data', 'nano-banana.db')
  
  db = await open({
    filename: dbPath,
    driver: sqlite3.Database
  })

  // Initialize tables
  await initializeTables()
  
  return db
}

async function initializeTables() {
  if (!db) return

  // Users table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `)

  // Blog posts table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      excerpt TEXT,
      author TEXT NOT NULL,
      image TEXT,
      published BOOLEAN DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `)

  // Pages table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS pages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL,
      published BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `)

  // Insert default admin user if not exists
  const adminExists = await db.get('SELECT id FROM users WHERE username = ?', ['admin'])
  if (!adminExists) {
    const bcrypt = require('bcryptjs')
    const hashedPassword = await bcrypt.hash('admin123', 10)
    await db.run(
      'INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)',
      ['admin', 'admin@nanobanana.ai', hashedPassword, 'admin']
    )
  }

  // Insert sample blog posts if not exists
  const postsCount = await db.get('SELECT COUNT(*) as count FROM posts')
  if (postsCount.count === 0) {
    await db.run(`
      INSERT INTO posts (title, slug, content, excerpt, author, published) VALUES 
      (
        'The Complete Guide to Nano Banana AI: Revolutionary Image Generation and Editing for Content Creators',
        'complete-guide-nano-banana-ai',
        '<h1>The Complete Guide to Nano Banana AI</h1><p>Nano Banana AI represents the next generation of artificial intelligence image generation technology...</p>',
        'Discover everything you need to know about Nano Banana AI - from what it is and why it''s superior to other tools, to best practices and step-by-step usage guide for content creators.',
        'William Jin',
        1
      ),
      (
        'The Ultimate Nano Banana Tutorial for 2025: The Best FREE AI Image Generation Tool',
        'ultimate-nano-banana-tutorial-2025',
        '<h1>The Ultimate Nano Banana Tutorial for 2025</h1><p>Discover Google''s revolutionary Nano Banana AI model...</p>',
        'Discover Google''s revolutionary Nano Banana AI model. Explore its capabilities in multi-image fusion, character consistency, and natural language image editing.',
        'William Jin',
        1
      )
    `)
  }
}

