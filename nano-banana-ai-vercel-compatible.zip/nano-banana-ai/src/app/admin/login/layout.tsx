export default function AdminLoginLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}

