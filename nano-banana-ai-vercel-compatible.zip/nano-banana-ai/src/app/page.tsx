'use client'

import { useState } from 'react'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Image from 'next/image'

export default function Home() {
  const [selectedTab, setSelectedTab] = useState('text-to-image')
  const [prompt, setPrompt] = useState('')
  const [aspectRatio, setAspectRatio] = useState('square')
  const [imageCount, setImageCount] = useState(4)

  const features = [
    {
      title: 'Advanced AI Technology',
      description: 'Built on cutting-edge artificial intelligence and machine learning advances, representing the forefront of image generation technology.',
      icon: '🤖'
    },
    {
      title: 'Intelligent Image Editing',
      description: 'Modify existing images using natural language commands. Simply describe what you want to change, and Nano Banana AI will seamlessly edit your images.',
      icon: '✨'
    },
    {
      title: 'High-Quality Results',
      description: 'Experience exceptional accuracy and artistic flair with text-to-image generation that understands nuanced prompts and delivers stunning results.',
      icon: '🎨'
    }
  ]

  const steps = [
    {
      number: '1',
      title: 'Describe Your Vision',
      description: 'Input a detailed text description of the image you want to create. Nano Banana AI analyzes your prompt, understands the context and requirements, then generates high-quality images that match your specifications.'
    },
    {
      number: '2',
      title: 'Click Generate',
      description: 'Hit the generate button and let Nano Banana AI work its magic. Most images are generated within 15-30 seconds with optimized processing that ensures fast turnaround times.'
    },
    {
      number: '3',
      title: 'Download & Share',
      description: 'Review the generated images. Pick your favorites, download them in high resolution, and share your creations with the world. Experience the power of advanced AI image generation!'
    }
  ]

  const testimonials = [
    {
      name: 'David Chen',
      role: 'Professional Photographer',
      content: 'Nano Banana AI has transformed my workflow completely. The advanced image generation and editing capabilities give my photos a quality that my clients absolutely love!',
      avatar: '👨‍💼'
    },
    {
      name: 'Rachel Kim',
      role: 'Digital Marketing Specialist',
      content: 'The speed and quality of Nano Banana AI is unmatched. I can create unique visuals for social media campaigns in minutes instead of hours. The variety of styles keeps our content fresh.',
      avatar: '👩‍💻'
    },
    {
      name: 'Marcus Thompson',
      role: 'Indie Game Developer',
      content: 'As a solo game developer, Nano Banana AI has been a game-changer for concept art. The advanced text-to-image generation helps me visualize characters quickly without hiring expensive artists.',
      avatar: '👨‍🎨'
    }
  ]

  const faqs = [
    {
      question: 'What makes Nano Banana AI different from other image generators?',
      answer: 'Nano Banana AI stands out through its exceptional text-based image editing capabilities and superior understanding of complex prompts. Unlike other AI image generators, it excels at both creating new images and modifying existing ones through natural language commands.'
    },
    {
      question: 'How does the text-to-image generation process work?',
      answer: 'Simply input a detailed text description of the image you want to create. Nano Banana AI analyzes your prompt, understands the context and requirements, then generates a high-quality image that matches your specifications. The more detailed your description, the more accurate the results.'
    },
    {
      question: 'Can I use Nano Banana AI for commercial projects?',
      answer: 'Yes, images generated with Nano Banana AI can be used for commercial purposes, including marketing materials, website content, and product designs. Please review our terms of service for specific usage guidelines.'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in">
            Transform Your Ideas Into{' '}
            <span className="gradient-text">Stunning Images</span>
            <br />
            with Nano Banana AI
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto animate-slide-up">
            The revolutionary text-to-image AI model that's taking the creative world by storm. 
            Generate, edit, and enhance images with unprecedented quality and precision.
          </p>
          
          {/* Feature badges */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <span className="px-4 py-2 bg-yellow-500/20 text-yellow-300 rounded-full text-sm border border-yellow-500/30">
              Advanced AI Model
            </span>
            <span className="px-4 py-2 bg-blue-500/20 text-blue-300 rounded-full text-sm border border-blue-500/30">
              Text-to-Image Generation
            </span>
            <span className="px-4 py-2 bg-purple-500/20 text-purple-300 rounded-full text-sm border border-purple-500/30">
              Intelligent Image Editing
            </span>
            <span className="px-4 py-2 bg-green-500/20 text-green-300 rounded-full text-sm border border-green-500/30">
              High-Resolution Output
            </span>
          </div>
        </div>
      </section>

      {/* AI Image Creator Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-8">
            ✨ AI Image Creator ✨
          </h2>
          
          {/* Tab Navigation */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            <button
              onClick={() => setSelectedTab('image-to-image')}
              className={`px-4 py-2 rounded-lg transition-all ${
                selectedTab === 'image-to-image'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Image to Image <span className="text-xs bg-red-500 px-1 rounded">HOT</span>
            </button>
            <button
              onClick={() => setSelectedTab('image-to-figure')}
              className={`px-4 py-2 rounded-lg transition-all ${
                selectedTab === 'image-to-figure'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Image to Figure <span className="text-xs bg-green-500 px-1 rounded">NEW</span>
            </button>
            <button
              onClick={() => setSelectedTab('image-editor')}
              className={`px-4 py-2 rounded-lg transition-all ${
                selectedTab === 'image-editor'
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Image Editor <span className="text-xs bg-purple-500 px-1 rounded">NEW</span>
            </button>
            <button
              onClick={() => setSelectedTab('text-to-image')}
              className={`px-4 py-2 rounded-lg transition-all ${
                selectedTab === 'text-to-image'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Text to Image
            </button>
          </div>

          {/* Main Creator Interface */}
          <div className="bg-gray-800/50 backdrop-blur-md rounded-2xl p-8 border border-gray-700">
            {/* Upload Area */}
            <div className="border-2 border-dashed border-gray-600 rounded-xl p-12 text-center mb-6 hover:border-gray-500 transition-colors">
              <div className="text-gray-400 mb-4">
                <svg className="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
              <p className="text-gray-300 text-lg">Upload Image</p>
            </div>

            {/* Controls */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-gray-300 mb-2">Select Style</label>
                <select className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600">
                  <option>Default Style</option>
                  <option>Anime Style</option>
                  <option>Realistic Style</option>
                  <option>Cartoon Style</option>
                </select>
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Aspect Ratio</label>
                <select 
                  value={aspectRatio}
                  onChange={(e) => setAspectRatio(e.target.value)}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600"
                >
                  <option value="square">□ Square (1:1)</option>
                  <option value="landscape">Landscape (16:9)</option>
                  <option value="portrait">Portrait (9:16)</option>
                </select>
              </div>
              
              <div>
                <label className="block text-gray-300 mb-2">Images</label>
                <select 
                  value={imageCount}
                  onChange={(e) => setImageCount(Number(e.target.value))}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 border border-gray-600"
                >
                  <option value={1}>1 Image</option>
                  <option value={2}>2 Images</option>
                  <option value={4}>4 Images</option>
                  <option value={8}>8 Images</option>
                </select>
              </div>
            </div>

            {/* Model Selection */}
            <div className="mb-6">
              <label className="block text-gray-300 mb-2">Model:</label>
              <div className="flex items-center space-x-4">
                <span className="px-3 py-1 bg-yellow-500/20 text-yellow-300 rounded-full text-sm border border-yellow-500/30">
                  Free
                </span>
                <span className="text-white">nano-banana</span>
              </div>
            </div>

            {/* Prompt Input */}
            <div className="mb-6">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe the image you want to create..."
                className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 border border-gray-600 h-24 resize-none"
              />
            </div>

            {/* Generate Button */}
            <button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all hover-glow">
              ✨ Generate
            </button>
          </div>
        </div>
      </section>

      {/* Transform Photos Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Transform Your Photos with AI</h2>
          <p className="text-gray-300 mb-12">Turn your photos into stunning Ghibli-style art or create adorable chibi avatars</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: 'Image to Figure', image: '/images/image_to_figure_example1.webp' },
              { title: 'Anime to Real', image: '/images/ghibli_style_example1.webp' },
              { title: 'Image to Figure', image: '/images/ghibli_style_example2.webp' },
              { title: '3D Chibi Avatar', image: '/images/image_to_image_gallery_example1.webp' }
            ].map((item, index) => (
              <div key={index} className="bg-gray-800/50 rounded-xl overflow-hidden hover:scale-105 transition-transform">
                <div className="aspect-square bg-gray-700 relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-pink-500/20"></div>
                </div>
                <div className="p-4">
                  <h3 className="text-white font-semibold mb-2">{item.title}</h3>
                  <button className="bg-green-500 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-600 transition-colors">
                    Try {item.title} Free
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What is Nano Banana AI Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-8">What is Nano Banana AI?</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Nano Banana AI represents the next generation of artificial intelligence image generation technology. 
                This state-of-the-art text-to-image model has emerged as a game-changer in the AI landscape, 
                offering exceptional capabilities in converting text descriptions into high-quality visual content.
              </p>
              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Originally gaining recognition on the LMArena platform for its outstanding performance in image 
                generation benchmarks, Nano Banana AI has quickly become the go-to solution for creators, marketers, 
                and developers seeking powerful AI image generation tools.
              </p>
            </div>
            <div className="space-y-6">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="text-2xl">{feature.icon}</div>
                  <div>
                    <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-400">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Steps Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Generate Stunning Images in 3 Simple Steps</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">{step.title}</h3>
                <p className="text-gray-400 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">What Users Say About Nano Banana AI</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-800/50 backdrop-blur-md rounded-xl p-6 border border-gray-700">
                <div className="flex items-center mb-4">
                  <div className="text-3xl mr-3">{testimonial.avatar}</div>
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-gray-400 text-sm">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-300 italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">Frequently Asked Questions About Nano Banana AI</h2>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-gray-800/50 backdrop-blur-md rounded-xl p-6 border border-gray-700">
                <h3 className="text-white font-semibold mb-3">{faq.question}</h3>
                <p className="text-gray-300">{faq.answer}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <p className="text-gray-400">Have another question? Contact us by email.</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

