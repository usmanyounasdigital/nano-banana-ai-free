import { NextRequest, NextResponse } from 'next/server'
import { getDatabase } from '@/lib/db/database'
import { verifyToken, isAdmin } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const db = await getDatabase()
    const { searchParams } = new URL(request.url)
    const published = searchParams.get('published')

    let query = 'SELECT * FROM posts'
    let params: any[] = []

    if (published === 'true') {
      query += ' WHERE published = 1'
    }

    query += ' ORDER BY created_at DESC'

    const posts = await db.all(query, params)
    return NextResponse.json({ posts })
  } catch (error) {
    console.error('Get posts error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('auth-token')?.value
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      )
    }

    const user = verifyToken(token)
    if (!user || !isAdmin(user)) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    const { title, slug, content, excerpt, author, image, published } = await request.json()

    if (!title || !slug || !content) {
      return NextResponse.json(
        { error: 'Title, slug, and content are required' },
        { status: 400 }
      )
    }

    const db = await getDatabase()
    
    // Check if slug already exists
    const existingPost = await db.get('SELECT id FROM posts WHERE slug = ?', [slug])
    if (existingPost) {
      return NextResponse.json(
        { error: 'Slug already exists' },
        { status: 400 }
      )
    }

    const result = await db.run(
      `INSERT INTO posts (title, slug, content, excerpt, author, image, published) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [title, slug, content, excerpt || '', author || user.username, image || '', published ? 1 : 0]
    )

    const newPost = await db.get('SELECT * FROM posts WHERE id = ?', [result.lastID])
    return NextResponse.json({ post: newPost }, { status: 201 })
  } catch (error) {
    console.error('Create post error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

