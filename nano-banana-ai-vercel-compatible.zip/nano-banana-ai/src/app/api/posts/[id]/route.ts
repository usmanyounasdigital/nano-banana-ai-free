import { NextRequest, NextResponse } from 'next/server'
import { getDatabase } from '@/lib/db/database'
import { verifyToken, isAdmin } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const db = await getDatabase()
    const post = await db.get('SELECT * FROM posts WHERE id = ? OR slug = ?', [params.id, params.id])

    if (!post) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ post })
  } catch (error) {
    console.error('Get post error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const token = request.cookies.get('auth-token')?.value
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      )
    }

    const user = verifyToken(token)
    if (!user || !isAdmin(user)) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    const { title, slug, content, excerpt, author, image, published } = await request.json()

    if (!title || !slug || !content) {
      return NextResponse.json(
        { error: 'Title, slug, and content are required' },
        { status: 400 }
      )
    }

    const db = await getDatabase()
    
    // Check if post exists
    const existingPost = await db.get('SELECT id FROM posts WHERE id = ?', [params.id])
    if (!existingPost) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    // Check if slug is taken by another post
    const slugCheck = await db.get('SELECT id FROM posts WHERE slug = ? AND id != ?', [slug, params.id])
    if (slugCheck) {
      return NextResponse.json(
        { error: 'Slug already exists' },
        { status: 400 }
      )
    }

    await db.run(
      `UPDATE posts SET 
       title = ?, slug = ?, content = ?, excerpt = ?, author = ?, image = ?, published = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [title, slug, content, excerpt || '', author || user.username, image || '', published ? 1 : 0, params.id]
    )

    const updatedPost = await db.get('SELECT * FROM posts WHERE id = ?', [params.id])
    return NextResponse.json({ post: updatedPost })
  } catch (error) {
    console.error('Update post error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const token = request.cookies.get('auth-token')?.value
    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      )
    }

    const user = verifyToken(token)
    if (!user || !isAdmin(user)) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    const db = await getDatabase()
    
    const existingPost = await db.get('SELECT id FROM posts WHERE id = ?', [params.id])
    if (!existingPost) {
      return NextResponse.json(
        { error: 'Post not found' },
        { status: 404 }
      )
    }

    await db.run('DELETE FROM posts WHERE id = ?', [params.id])
    return NextResponse.json({ message: 'Post deleted successfully' })
  } catch (error) {
    console.error('Delete post error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

