import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Nano Banana AI - Free Advanced Text-to-Image Generation Model',
  description: 'The revolutionary text-to-image AI model that\'s taking the creative world by storm. Generate, edit, and enhance images with unprecedented quality and precision.',
  keywords: 'AI, image generation, text-to-image, artificial intelligence, nano banana, free AI tool',
  authors: [{ name: 'Nano Banana AI Team' }],
  openGraph: {
    title: 'Nano Banana AI - Free Advanced Text-to-Image Generation Model',
    description: 'Transform your ideas into stunning images with Nano Banana AI',
    type: 'website',
    locale: 'en_US',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nano Banana AI - Free Advanced Text-to-Image Generation Model',
    description: 'Transform your ideas into stunning images with Nano Banana AI',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}

